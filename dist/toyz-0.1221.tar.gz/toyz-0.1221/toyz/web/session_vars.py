"""
Empty module used to store variables shared in a single Toyz session (websocket connection).
""" 