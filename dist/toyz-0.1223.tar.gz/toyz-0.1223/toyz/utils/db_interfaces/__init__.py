# Licensed under a 3-clause BSD license - see LICENSE.md

"""
Common non-package specific utility functions
"""

from toyz.utils.db_interfaces import sqlite_interface