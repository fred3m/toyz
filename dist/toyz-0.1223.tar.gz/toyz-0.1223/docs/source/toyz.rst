toyz package
============

Subpackages
-----------

.. toctree::

    toyz.utils
    toyz.web

Submodules
----------

toyz.version module
-------------------

.. automodule:: toyz.version
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: toyz
    :members:
    :undoc-members:
    :show-inheritance:
