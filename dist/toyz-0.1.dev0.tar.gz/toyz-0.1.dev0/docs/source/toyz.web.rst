toyz.web package
================

Submodules
----------

toyz.web.app module
-------------------

.. automodule:: toyz.web.app
    :members:
    :undoc-members:
    :show-inheritance:

toyz.web.tasks module
---------------------

.. automodule:: toyz.web.tasks
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: toyz.web
    :members:
    :undoc-members:
    :show-inheritance:
